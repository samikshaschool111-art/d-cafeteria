const items=[
{name:"Espresso",price:"Rs 80",cat:"coffee",desc:"Classic espresso"},
{name:"Cappuccino",price:"Rs 165 / 195",cat:"coffee",desc:"Hot / iced"},
{name:"Caramel Macchiato",price:"Rs 195",cat:"coffee",desc:"Smooth caramel coffee"},
{name:"Café Latte",price:"Rs 165 / 195",cat:"coffee",desc:"Hot / iced"},
{name:"Mocha",price:"Rs 195",cat:"coffee",desc:"Rich chocolate coffee"},
{name:"D Cafeteria Iced Coffee",price:"Rs 155",cat:"cold",desc:"House iced coffee"},
{name:"Iced Blended Mocha",price:"Rs 215 / 255",cat:"cold",desc:"Blended and chilled"},
{name:"Virgin Mojito",price:"Rs 195",cat:"cold",desc:"Fresh mint refresher"},
{name:"Watermelon / Apple Juice",price:"Rs 250",cat:"cold",desc:"Seasonal juice"},
{name:"Hot Peach / Apple Tea",price:"Rs 85",cat:"tea",desc:"Warm fruit tea"},
{name:"Black Tea",price:"Rs 45",cat:"tea",desc:"Classic black tea"},
{name:"Green Tea",price:"Rs 75",cat:"tea",desc:"Light green tea"},
{name:"Lemon / Ginger Tea",price:"Rs 75",cat:"tea",desc:"Fresh citrus & ginger"},
{name:"D Cafeteria Chips Frappe",price:"Rs 315",cat:"special",desc:"House special"},
{name:"Blended Double Fun Vanilla Mocha",price:"Rs 315",cat:"special",desc:"House special"},
{name:"Blue Iced Latte",price:"Rs 215",cat:"special",desc:"House special"},
{name:"Dalgona Coffee",price:"Rs 175",cat:"special",desc:"Whipped coffee"},
{name:"Iced Coffee With Ice Cream",price:"Rs 235",cat:"special",desc:"Coffee & ice cream"}
];

const full=document.getElementById("full-menu");
const preview=document.getElementById("preview-items");

function renderFull(cat="all"){
 const list=cat==="all"?items:items.filter(x=>x.cat===cat);
 full.innerHTML=list.map(x=>`<article class="menu-item"><div><h4>${x.name}</h4><p>${x.desc}</p></div><span class="menu-price">${x.price}</span></article>`).join("");
}

function renderPreview(cat="all"){
 const list=(cat==="all"?items:items.filter(x=>x.cat===cat)).slice(0,6);
 preview.innerHTML=list.map(x=>`<div class="preview-row"><span>${x.name}</span><span>${x.price}</span></div>`).join("");
}

document.querySelectorAll(".filter").forEach(btn=>{
 btn.addEventListener("click",()=>{
  document.querySelector(".filter.active").classList.remove("active");
  btn.classList.add("active");
  renderFull(btn.dataset.category);
 });
});

document.querySelectorAll(".mini-tabs button").forEach(btn=>{
 btn.addEventListener("click",()=>{
  document.querySelector(".mini-tabs .selected").classList.remove("selected");
  btn.classList.add("selected");
  renderPreview(btn.dataset.menu);
 });
});

document.querySelector(".nav-toggle").addEventListener("click",()=>{
 document.getElementById("nav").classList.toggle("open");
});

document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>{
 document.getElementById("nav").classList.remove("open");
}));

renderFull();
renderPreview();
